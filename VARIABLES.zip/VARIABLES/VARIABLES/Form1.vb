﻿Public Class Form1

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        Dim strName As String
        Dim shrtAge As Short
        Dim dblSal As Double

        strName = txtName.Text
        shrtAge = txtAge.Text
        dblSal = txtSal.Text


        lblResults.Text = strName & " is " & shrtAge & " old " & " and makes about " & dblSal.ToString("c") & " a year "

    End Sub
End Class
